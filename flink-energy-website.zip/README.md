# flink.energy — Website

Statische Website für **Flink Energy · Making Renewables Bankable**, gehostet über GitHub Pages.

## Dateien

| Datei | Zweck |
|---|---|
| `index.html` | Startseite mit Hero, Fokus-Themen, Ausgaben-Archiv und Advisory-Kontakt |
| `briefing/template.html` | Master-Vorlage für die täglichen Briefing-Ausgaben |
| `impressum.html` | Impressum — **Platzhalter vor Go-live ausfüllen (§ 5 DDG)** |
| `CNAME` | Bindet die Domain flink.energy — **niemals löschen** |

Logo und Favicon sind als Base64 direkt in die HTML-Dateien eingebettet — es gibt keine Bild-Dateien, die kaputtgehen können.

## Neue Briefing-Ausgabe veröffentlichen

1. `briefing/template.html` kopieren und als `briefing/JJJJ-MM-TT.html` speichern (z. B. `briefing/2026-08-18.html`).
2. Alle `[SAMPLE]`-Blöcke durch echte Inhalte ersetzen, Ausgabennummer und Datum im Kopf anpassen, `<meta name="robots" content="noindex">` entfernen.
3. In `index.html` im Abschnitt *Editions* den auskommentierten Archiv-Block kopieren, Datum/Dateiname/Titel eintragen und **oberhalb** der bestehenden Zeilen einfügen. Beim ersten Mal zusätzlich den „in production"-Block löschen.
4. Beide Dateien ins Repository hochladen (*Add file → Upload files*) — nach ca. einer Minute ist die Ausgabe live.

## Noch offene Platzhalter

- `hello@flink.energy` in `index.html` durch die echte Kontaktadresse ersetzen (2×).
- `impressum.html` vollständig ausfüllen, dann den orangen Hinweiskasten löschen.

## Farben & Schriften (für konsistente Erweiterungen)

Teal `#00A99D` · Deep Teal `#00776E` · Orange `#F78F16` (sparsam: Watch-Items, Akzente) · Ink `#0B2725` · Mint `#EFF7F5` — Schriften: Fraunces (Display), IBM Plex Sans (Text), IBM Plex Mono (Labels/Daten).
